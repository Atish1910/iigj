 <!-- Spinner Start -->
 <div id="spinner"
     class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
     <div class="spinner-border text-primary" role="status" style="width: 3rem; height: 3rem;"></div>
 </div>
 <!-- Spinner End -->
 <!-- <div class="container-fluid bg-dark text-white d-lg-flex">
     <div class="container pt-2 pb-1">
         <div class="d-flex">
             <img src="<?= LINK; ?>images/import1.png" height="30px" alt="">
             <marquee>CV Raman Global University: India's Best University in Odisha </marquee>
         </div>
     </div>
 </div> -->
 <!-- Topbar End -->

 <!-- Navbar Start -->
 <div class="container-fluid pt-0 sticky-top h_nav">
     <div class="container">
         <nav class="navbar navbar-expand-lg  navbar-light p-lg-0">
             <a href="<?= LINK; ?>" class="navbar-brand">
                 <img src="images/iigj/logo/1.jpg" class="pt-2" alt="">
             </a>
             <div class=""></div>
             <button type="button" class="navbar-toggler me-0" data-bs-toggle="collapse"
                 data-bs-target="#navbarCollapse">
                 <span class="navbar-toggler-icon"></span>
             </button>
             <div class="collapse navbar-collapse justify-content-end " id="navbarCollapse">
                 <!-- <div class="d-none d-lg-block">
                     <img src="images/logo.png" alt="">
                 </div> -->
                 <div class="navbar-nav">
                     <a href="<?= LINK; ?>" class="nav-item nav-link"><i class="fas fa-home fs-5 me-1"></i></a>
                     <a href="#n_courses" class="nav-item nav-link">Courses </a>
                     <a href="#n_placement" class="nav-item nav-link">Placement</a>
                     <a href="#n_about" class="nav-item nav-link">About </a>
                     <a href="#n_corporate" class="nav-item nav-link">Corporate Training </a>
                     <a href="#n_location" class="nav-item nav-link">Location</a>
                     <div class="d-lg-block">
                         <a href="<?= LINK; ?>" class="btn c_btn py-2 px-3 ms-2 mt-3 "
                             data-bs-toggle="modal" data-bs-target="#exampleModal">Apply Now</a>
                     </div>
                 </div>
             </div>
             <!-- <div class="ms-auto d-none d-lg-block">
                        <a href="<?= LINK; ?>" class="btn btn-primary rounded-pill py-2 px-3">Get A Quote</a>
                    </div> -->
         </nav>
     </div>
 </div>
 <!-- Navbar End -->