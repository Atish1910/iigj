
<div class="bg-white">
    <iframe aria-label='IIGJ 2024' frameborder="0" style="height:585px;width:99%;border:none;" src='https://forms.zohopublic.in/gladowlwebsolutionspvtltd/form/IIGJ2024/formperma/_JA9W9VlYbq2e51ABp-8BIpZSwBxFrZmYJQjvlsKWk8'></iframe>
</div>